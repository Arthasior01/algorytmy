﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace stosy_i_kolejka
{
    abstract class SD
    {
        protected int[] dane;
        public int Lenght => this.dane.Length;
        public int this[int index]
        {
            get { return this.dane[index]; }
            set { this.dane[index] = value; }
        }

        public SD()
        {
            this.dane = new int[0];
        }

        public void Push(int a)
        {
            var nowa = this.Przepisz();
            nowa[nowa.Length - 1] = a;
            this.dane = nowa; 

        }
        protected int[] Przepisz()
        {
            int[] nowa = new int[this.dane.Length + 1];
            for(int i=0; i<this.dane.Length;i++)
            {
                nowa[i] = this.dane[i];
            }
            return nowa;
        }
    }
    
    class Stos : SD, IAiSD
    {
        public int Pop()
        {
            int[] nowa = new int[dane.Length - 1];
            for (int i = 0; i < nowa.Length; i++)
            {
                nowa[i] = dane[i];
            }
            dane = nowa;
            return dane[dane.Length];
        }
    }
    class Kolejka : SD,IAiSD
    {
        public int Pop()
        {
            int[] nowa = new int[dane.Length - 1];
            for (int i = 0; i < nowa.Length; i++)
            {
                nowa[i] = dane[i + 1];
            }
            dane = nowa;
            return dane[0];
        }
    }
}
